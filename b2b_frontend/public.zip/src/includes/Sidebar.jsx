import React from "react";
const Sidebar = () => {
  return (
    <div>
     SideBar
    </div>
  );
};

export default Sidebar;
